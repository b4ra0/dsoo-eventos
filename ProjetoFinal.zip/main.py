from controle.controlador_principal import ControladorPrincipal

if __name__ == "__main__":
  ControladorPrincipal().inicializa_sistema()